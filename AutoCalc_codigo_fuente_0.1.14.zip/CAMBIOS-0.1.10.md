# Auto Calc 0.1.10 — deshacer y copias de seguridad

## Uso

En Liquidación vendedor hay dos botones nuevos: Deshacer cambio (Ctrl+Alt+Z) y Rehacer cambio (Ctrl+Alt+Y). Conservan hasta 50 cambios de filas del borrador durante la sesión, incluidos añadir, editar, borrar, cambiar cantidades, vaciar con Nueva liquidación y cargar otra liquidación. Recuperan las fechas y notas que acompañaban al estado anterior. No registran por separado cada letra o cada cambio de fecha. Al guardar una liquidación o una corrección, o eliminar una liquidación guardada, se vacía este historial. Las revisiones históricas siguen disponibles por su mecanismo habitual.

El menú Copias de seguridad permite crear una copia ahora, exportar un ZIP a otra carpeta o restaurar una copia. La aplicación crea una al abrir y comprueba cada 15 minutos si hay cambios. Conserva las últimas 20 en %APPDATA%/AutoCalcAvanzadaLiquidacion/copias-seguridad. Las copias incluyen el borrador, la fecha, la nota, las liquidaciones y sus revisiones, y el historial de cálculos. No incluyen el inventario, ajustes ni conexiones. Las exportadas a otra carpeta no se borran por rotación. Copiarlas a otra unidad protege también frente a una avería del disco.

Antes de restaurar se valida la copia, se pide confirmación y se crea una copia adicional del estado actual. Se sustituyen los datos locales y se desactiva la sincronización automática para revisarlos. No se modifica la nube ni se recuperan borrados ya sincronizados. Al sincronizar de nuevo siguen aplicándose las reglas existentes de combinación y eliminaciones.

La fecha y la nota del borrador se guardan al cerrar normalmente. Deshacer y rehacer no se conservan al cerrar.

## Instalación

Incluye la mejora de apertura de 0.1.8 y el cierre previo a la instalación de 0.1.9. Si la versión actualmente abierta es 0.1.8 o anterior, ciérrala manualmente antes de instalar. Esta versión se entrega localmente y no se ha publicado en GitHub.

## Validación

Compilación correcta. Pruebas superadas de cálculos, persistencia, correcciones, nube simulada, cierre con Escape, espera al cierre para instalar, lanzador, deshacer/rehacer, límite de 50 cambios, atajos, restauración con revisiones, fecha y nota al reabrir, copia previa a restaurar, rechazo de copias inválidas, rotación de 20 archivos y copias automáticas en segundo plano sin duplicación.

Pendiente de validar con NVDA real: navegación, anuncios y uso de los selectores de archivo. La copia ZIP de esta versión admite como máximo 10 MB descomprimidos; la restauración respeta el límite previo de 2 MB por lista del almacenamiento de la calculadora.
