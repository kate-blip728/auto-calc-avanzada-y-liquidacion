# Auto Calc 0.1.9 — cierre antes de actualizar

Corregido: el actualizador abría el instalador mientras AutoCalc.exe seguía ejecutándose. Ahora inicia un auxiliar oculto de Windows, solicita el cierre normal de la calculadora y espera a la salida del proceso antes de abrir el paquete verificado. El cierre utiliza los guardados existentes. No fuerza la terminación del proceso.

El auxiliar reconoce el proceso por identificador y hora de inicio, admite rutas con espacios y apóstrofos y evita instalar si Auto Calc no termina en 60 segundos. Los fallos dejan un archivo .install-error.txt junto al paquete descargado, dentro de la carpeta actualizaciones de los datos de Auto Calc.

Pruebas superadas: espera real a la salida de un proceso de prueba, ejecución posterior de un instalador simulado, rutas con espacios y apóstrofos, diagnóstico de fallo de apertura, cálculos, persistencia, Escape y lanzador. Pendiente: instalación completa y anuncios con NVDA real.

Para instalar esta corrección desde una versión anterior, cerrar manualmente Auto Calc antes de instalar AutoCalc-0.1.9.nvda-addon. El cierre automático se aplica a actualizaciones iniciadas desde 0.1.9. No cambia instalaciones iniciadas desde la tienda de complementos de NVDA.

Conserva la mejora de velocidad de 0.1.8. Esta entrega no está publicada en GitHub.
